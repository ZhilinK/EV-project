class Shuffle:
    """
    Different kinds of shuffling techniques.

    >>> cards = [i for i in range(52)]
    >>> cards[25]
    25
    >>> mod_oh = Shuffle.modified_overhand(cards, 1)
    >>> mod_oh[0]
    25
    >>> mod_oh[25]
    24

    >>> mongean_shuffle = Shuffle.mongean(mod_oh)
    >>> mongean_shuffle[0]
    51
    >>> mongean_shuffle[26]
    25

    >>> odd_cards = [1, 2, 3, 4, 5]
    >>> mod_oh_even = Shuffle.modified_overhand(odd_cards, 2)
    >>> mod_oh_even
    [1, 2, 3, 4, 5]
    >>> cards=[i for i in range(9)]
    >>> lst=Shuffle.modified_overhand(cards,1)
    >>> print(lst)
    [4, 0, 1, 2, 3, 5, 6, 7, 8]
    >>> lst1=Shuffle.modified_overhand(cards,3)
    >>> print(lst1)
    [5, 0, 1, 3, 4, 2, 6, 7, 8]
    >>> cards=[i for i in range(10)]
    >>> lst2=Shuffle.modified_overhand(cards,2)
    >>> print(lst2)
    [2, 4, 5, 0, 1, 3, 6, 7, 8, 9]
    >>> cards=[i for i in range(9)]
    >>> lst3=Shuffle.modified_overhand(cards,2)
    >>> print(lst3)
    [2, 3, 4, 0, 1, 5, 6, 7, 8]
    >>> cards=[i for i in range(9)]
    >>> lst4=Shuffle.modified_overhand(cards,5)
    >>> print(lst4)
    [3, 4, 5, 0, 2, 6, 1, 7, 8]

    >>> cards=[1,2,3,4,5,6,7,8,9]
    >>> lst=Shuffle.mongean(cards)
    >>> print(lst)
    [8, 6, 4, 2, 1, 3, 5, 7, 9]
    >>> cards=[1,2,3,4,5,6,7,8,9,10]
    >>> lst=Shuffle.mongean(cards)
    >>> print(lst)
    [10, 8, 6, 4, 2, 1, 3, 5, 7, 9]
    >>> cards=[1,2,3,4,5,6,7,8,9,10,11]
    >>> lst=Shuffle.mongean(cards)
    >>> print(lst)
    [10, 8, 6, 4, 2, 1, 3, 5, 7, 9, 11]
    >>> cards=[1,2,3,4,5]
    >>> lst=Shuffle.modified_overhand(cards,2)
    >>> print(lst)
    [1, 2, 3, 4, 5]
    """

    def modified_overhand(cards, num):
        """
        Takes `num` cards from the middle of the deck and puts them at the
        top.
        Then decrement `num` by 1 and continue the process till `num` = 0.
        When num is odd, the "extra" card is taken from the bottom of the
        top half of the deck.
        """
        # Use Recursion.
        # Note that the top of the deck is the card at index 0.
        assert isinstance(cards,list)
        assert len(cards) > 0
        assert isinstance(num, int)
        assert num >= 0
        assert len(cards) >= num
        if num == 0:
            return cards
        if num == 1:
            if len(cards) % 2 ==0:
                middle_index = int((len(cards) / 2) - 1)
                middle = [cards[middle_index]]
                top = cards[:middle_index]
                bottom = cards[middle_index+1:]
                cards=middle+top+bottom
                return Shuffle.modified_overhand(cards, num-1)
            else:
                middle_index = int(len(cards)/2)
                middle = [cards[middle_index]]
                top = cards[:middle_index]
                bottom = cards[middle_index+1:]
                cards=middle+top+bottom
                return Shuffle.modified_overhand(cards, num-1)
        if (len(cards)%2==0 and num%2==0) or (len(cards)%2==1 and num%2==1):
            num_discard=len(cards)-num
            index_discard=int(num_discard/2)
            middle=cards[index_discard:-index_discard]
            top=cards[:index_discard]
            bottom=cards[-index_discard:]
            cards=middle+top+bottom
            return Shuffle.modified_overhand(cards, num-1)
        elif len(cards)%2==0 and num%2==1:
            index_middle = int(len(cards)/2)-1
            one_side = int((num-1)/2)
            middle = cards[index_middle-one_side:index_middle+one_side+1]
            top=cards[:index_middle-one_side]
            bottom=cards[index_middle+one_side+1:]
            cards=middle+top+bottom
            return Shuffle.modified_overhand(cards, num-1)
        elif len(cards)%2==1 and num%2==0:
            index_middle=int((len(cards))/2)
            index_start=index_middle-int(num/2)
            middle=cards[index_start:index_middle+int(num/2)]
            top=cards[:index_start]
            bottom=cards[index_middle+int(num/2):]
            cards=middle+top+bottom
            return Shuffle.modified_overhand(cards, num-1)


    def mongean(cards):
        """
        Implements the mongean shuffle.
        Check wikipedia for technique description. Doing it 12 times restores the deck.
        """
        # Remember that the "top" of the deck is the first item in the list.
        # Use Recursion. Can use helper functions.
        def innereven(cards):
            even=2
            output=[]
            if len(cards)==0:
                return output
            else:
                output+=[cards[0]]
                return output+innereven(cards[even:])

        def innerodd(cards):
            even=2
            output=[]
            if len(cards)<=1:
                return output
            else:
                output+=[cards[1]]
                return output+innerodd(cards[even:])
        return innerodd(cards)[::-1]+innereven(cards)
