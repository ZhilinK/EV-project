class Card:
    """
    Card class.

    # Doctests for str and repr
    >>> card_1 = Card("A", "spades")
    >>> print(card_1)
    ____
    |A  |
    | ♠ |
    |__A|
    >>> card_1
    (A, spades)
    >>> card_2 = Card("K", "spades")
    >>> print(card_2)
    ____
    |K  |
    | ♠ |
    |__K|
    >>> card_2
    (K, spades)
    >>> card_3 = Card("A", "diamonds")
    >>> print(card_3)
    ____
    |A  |
    | ♦ |
    |__A|
    >>> card_3
    (A, diamonds)

    # Doctests for comparisons
    >>> card_1 < card_2
    False
    >>> card_1 > card_2
    True
    >>> card_3 > card_1
    True

    # Doctests for set_visible()
    >>> card_3.set_visible(False)
    >>> print(card_3)
    ____
    |?  |
    | ? |
    |__?|
    >>> card_3
    (?, ?)
    >>> card_3.set_visible(True)
    >>> print(card_3)
    ____
    |A  |
    | ♦ |
    |__A|
    >>> card_3
    (A, diamonds)
    """

    # Class Attribute(s)

    def __init__(self, rank, suit, visible=True):
        """
        Creates a card instance and asserts that the rank and suit are valid.
        ---
        parameters:
        rank:int or str representing value of card. int(2-10), str(A J Q K)
        suit: str represent suit of card (hearts, spades, clubs, diamonds)
        visible: boolean value indicate card visible or not to others
        """
        self.rank=rank
        self.suit=suit
        self.visible=visible


    def __lt__(self, other_card):
        """'<' operator overloading method """
        #return boolean value
        #first compare the ranks
        Jack = 11
        Queen = 12
        King = 13
        Ace = 14
        if isinstance(self.rank, int):
            self.num = self.rank
        else:
            if self.rank == 'J':
                self.num = Jack
            if self.rank == 'Q':
                self.num = Queen
            if self.rank == 'K':
                self.num = King
            if self.rank == 'A':
                self.num = Ace

        if isinstance(other_card.rank, int):
            other_card.num = other_card.rank
        else:
            if other_card.rank == 'J':
                other_card.num = Jack
            if other_card.rank == 'Q':
                other_card.num = Queen
            if other_card.rank == 'K':
                other_card.num = King
            if other_card.rank == 'A':
                other_card.num = Ace


        if self.num == other_card.num:
            if self.get_suit() < other_card.get_suit():
                return False
            elif self.get_suit() > other_card.get_suit():
                return True
            else:
                return False
        elif self.num < other_card.num:
            return True
        return False
        ...


    def __str__(self):
        """
        Returns ASCII art of a card with the rank and suit. If the card is
        hidden, question marks are put in place of the actual rank and suit.

        Examples:
        ____
        |A  |
        | ♠ |
        |__A|
        ____
        |?  |
        | ? |
        |__?|
        """
        hearts   = chr(9829) # Character 9829 is '♥'.
        diamonds = chr(9830) # Character 9830 is '♦'.
        spades   = chr(9824) # Character 9824 is '♠'.
        clubs    = chr(9827) # Character 9827 is '♣'.
        if self.suit=='hearts':
            pattern=hearts
        if self.suit=='diamonds':
            pattern=diamonds
        if self.suit=='spades':
            pattern=spades
        if self.suit=='clubs':
            pattern=clubs
        if self.visible==False:
            return '____\n|{}  |\n| {} |\n|__{}|'.format('?','?','?')
        return '____\n|{}  |\n| {} |\n|__{}|'\
        .format(self.rank,pattern,self.rank)


    def __repr__(self):
        """
        Returns (rank>, <suit>). If the card is hidden, question marks are
        put in place of the actual rank and suit.
        """
        if self.visible:
            return '({}, {})'.format(self.rank, self.suit)
        else:
            return '({}, {})'.format('?','?')

        ...

    def get_rank(self):
        '''
        getter of the rank attribute
        '''
        return self.rank

    def get_suit(self):
        '''
        getter of the suit attribute
        '''
        return self.suit

    def set_visible(self, visible):
        '''
        setter of the visible attribute
        '''
        assert isinstance(visible,bool)
        self.visible = visible
        return
