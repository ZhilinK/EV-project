from card import Card
from hand import PlayerHand, DealerHand
from shuffle import Shuffle

class Deck:
    """
    Card deck of 52 cards.

    >>> deck = Deck()
    >>> deck.get_cards()[:5]
    [(2, spades), (2, hearts), (2, diamonds), (2, clubs), (3, spades)]

    >>> deck.shuffle(modified_overhand=2, mongean=3)
    >>> deck.get_cards()[:5]
    [(A, spades), (Q, spades), (10, spades), (7, hearts), (5, hearts)]

    >>> hand = PlayerHand()
    >>> deck.deal_hand(hand)
    >>> deck.get_cards()[0]
    (Q, spades)
    """

    # Class Attribute(s)

    def __init__(self):
        """
        Creates a Deck instance containing cards sorted in ascending order.
        """
        suit = ['spades','hearts','diamonds','clubs']
        rank = [2,3,4,5,6,7,8,9,10,'J','Q','K','A']
        self.cards=[Card(i,j) for i in rank for j in suit]

    def shuffle(self, **shuffle_and_count):
        """Shuffles the deck using a variety of different shuffles.

        Parameters:
            shuffle_and_count: keyword arguments containing the
            shuffle type and the number of times the shuffled
            should be called.
        """
        assert all([k == 'modified_overhand' or\
               k == 'mongean' for k in shuffle_and_count.keys()])
        assert all(isinstance(v,int) for v in shuffle_and_count.values())
        #modified_overhand first then mongean_shuffle
        sorted_dict = dict(sorted(shuffle_and_count.items()))
        #dictionary has been sorted by keys
        for k,v in sorted_dict.items():
            if k == 'modified_overhand':
                self.cards=Shuffle.modified_overhand(self.cards, v)
            else:
                for i in range(v):
                    self.cards=Shuffle.mongean(self.cards)


    def deal_hand(self, hand):
        """
        Takes the first card from the deck and adds it to `hand`.
        """
        assert isinstance(hand,PlayerHand)
        if isinstance(hand, DealerHand):
            if hand.hand_visible:
                #add_card contains sorted method
                hand.add_card(self.cards[0])
            else:
                hand.cards=hand.cards+[self.cards[0]]
        else:
            hand.cards=hand.cards+[self.cards[0]]
        self.poped=self.cards.pop(0)




    def get_cards(self):
        return self.cards
